import { Body, Controller, Delete, Get, Param, Post, Put } from '@nestjs/common';
import { UserService } from './user.service';

@Controller('users')
export class UserController {
    constructor(private readonly service: UserService) { }

    @Get()
    async findAll() {
        console.log('GET /users 요청 받음');
        try {
            return await this.service.findAll();
        } catch (error) {
            throw new Error(`Failed to fetch users: ${error.message}`);
        }
    }

    @Post()
    async create(@Body() body: { name: string; email: string }) {
      console.log('POST /users 요청 받음', body);
      return this.service.create(body);
    }

    @Put(':id')
    async update(@Param('id') id: string, @Body() body: { name?: string; email?: string }) {
        console.log('update 요청 받음', body);
        return this.service.update(Number(id), body);
    }

    @Delete(':id')
    async delete(@Param('id') id: string) {
        console.log('delete 요청 받음',);
        return this.service.delete(Number(id));
    }
}
