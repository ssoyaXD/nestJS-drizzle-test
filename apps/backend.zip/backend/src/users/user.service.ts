import { Inject, Injectable } from '@nestjs/common';
import { DrizzleDb } from '@db';
import { users } from '@db';
import { eq } from 'drizzle-orm';

@Injectable()
export class UserService {
  constructor(@Inject('DB') private readonly db: DrizzleDb) { }

  async findAll() {
    try {
      // DB 연결 확인을 위한 테스트 쿼리 실행
      const testConnection = await this.db.select().from(users).limit(1);
      console.log('DB 연결 성공:', testConnection);

      return await this.db.select().from(users);
    } catch (error) {
      console.error('DB 연결 실패:', error);
      throw new Error('데이터베이스 연결 실패');
    }
  }

  async create(data: { name: string; email: string }) {
    return await this.db.insert(users).values(data).returning();
  }

  async update(id: number, data: { name?: string; email?: string }) {
    return await this.db
      .update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
  }

  async delete(id: number) {
    return await this.db.delete(users).where(eq(users.id, id));
  }
}

